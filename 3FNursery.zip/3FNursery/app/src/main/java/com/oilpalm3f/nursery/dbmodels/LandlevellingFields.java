package com.oilpalm3f.nursery.dbmodels;

public class LandlevellingFields {

    private int Value;
    private String Field;

    public int getValue() {
        return Value;
    }

    public void setValue(int value) {
        Value = value;
    }

    public String getField() {
        return Field;
    }

    public void setField(String field) {
        Field = field;
    }
}
