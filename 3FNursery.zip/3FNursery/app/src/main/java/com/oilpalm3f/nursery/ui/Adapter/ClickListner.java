package com.oilpalm3f.nursery.ui.Adapter;

import com.oilpalm3f.nursery.dbmodels.SaplingActivity;

public interface ClickListner {
    void onNotificationClick(int po, SaplingActivity  saplings);
}
