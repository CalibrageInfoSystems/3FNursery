package com.oilpalm3f.nursery.ui;

public interface LatLongListener {
    void getLatLong(String mLatLong);
}
