package com.oilpalm3f.nursery.ui;

public interface ImageClickListener{
    void onImageClicked(int Id);
}